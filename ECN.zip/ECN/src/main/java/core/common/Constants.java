package core.common;

public class Constants {

}
