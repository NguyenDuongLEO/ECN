package core.pageobject;

public class BasePage {

}
