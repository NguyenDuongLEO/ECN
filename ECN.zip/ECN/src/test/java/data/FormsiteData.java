package data;

public class FormsiteData {
    public static final String URL = "https://fs28.formsite.com/ecnvietnam/form1/index.html";
    public static final String PASSWORDLOGIN ="secret";
    public static final String FIRSTNAME = "Nguyen";
    public static final String LASTNAME = "Duong";
    public static final String STREETADDRESS = "Ton Duc Thang";
    public static final String ADDRESSLINE2 = "Ben Nghe";
    public static final String CITY = "HCM";
    public static final String STATE = "New York";
    public static final String ZIPCODE = "700000";
    public static final String PHONENUMBER = "12345678";
    public static final String EMAILADDRESS = "leonguyenduong@gmail.com";
    public static final String DATEOFDEMO = "30/04/2018";
    public static final String RESULTSTATUS = "Complete";
}
